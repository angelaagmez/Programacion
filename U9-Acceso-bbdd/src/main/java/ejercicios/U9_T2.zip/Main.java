package ejercicios;

import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        ConexionBD con = new ConexionBD();
        ADClassicModels ad = new ADClassicModels();


        System.out.println(con.conector());

        System.out.println(ad.getEmpleados(con));
        System.out.println(ad.getOffices(con));
    }
}
