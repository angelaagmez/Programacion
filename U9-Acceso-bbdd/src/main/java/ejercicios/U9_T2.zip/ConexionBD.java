package ejercicios;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConexionBD {
    public static void main(String[] args) {
        ConexionBD cb = new ConexionBD();
        System.out.println(cb.conector());
    }

    public Connection conector(){
        try(Connection con = DriverManager.getConnection("jdbc:mariadb://localhost:3333/classicmodels?user=root&password=123456")){
            return con;
        } catch (SQLException e){
            e.getStackTrace();
        }
        return null;
    }

    public void close(Connection con){
        try{
            con.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

}
