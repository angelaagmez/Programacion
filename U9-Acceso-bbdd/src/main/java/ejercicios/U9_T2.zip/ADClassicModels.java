package ejercicios;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ADClassicModels {

    public List<Employee> getEmpleados(ConexionBD con)  {
        Connection con2 = con.conector();
        try{
            List<Employee> lista_empleados = new ArrayList<>();

            String sql = "SELECT * FROM employees";
            PreparedStatement sentencia = con2.prepareStatement(sql);

            ResultSet result = sentencia.executeQuery();

            while (result.next()){
                Employee empleado = new Employee(result);
                lista_empleados.add(empleado);
            }
            return lista_empleados;
        } catch (SQLException e){
            System.out.println(e.getMessage());
        } finally {
            con.close(con2);
        }
        return null;
    }

    public List<Office> getOffices(ConexionBD con) {
        Connection con2 = con.conector();

        try {
            List<Office> lista_oficinas = new ArrayList<>();

            String sql = "SELECT * FROM offices";
            PreparedStatement sentencia = con2.prepareStatement(sql);

            ResultSet result = sentencia.executeQuery();

            while (result.next()) {
                Office oficina = new Office(result);
                lista_oficinas.add(oficina);
            }
            return lista_oficinas;
        } catch (SQLException e) {
            e.getStackTrace();
        } finally {
            con.close(con2);
        }
        return null;
    }
}
