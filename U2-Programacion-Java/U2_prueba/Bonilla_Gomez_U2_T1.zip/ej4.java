package com.abg;

// Escribir un programa que incremente la hora de un reloj tantos segundos como le solicitemos mostrando cada vez
// la hora nueva.
//Se solicitará al usuario por teclado las horas, los minutos y los segundos y el número de segundos que se quiere
// aumentar la hora.

import java.util.Scanner;

public class ej4 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int horas,minutos,segundos,ausegundos;

        System.out.println("Introduce las horas");
        horas = sc.nextInt();
        System.out.println("Introduce los minutos");
        minutos = sc.nextInt();
        System.out.println("Introduce los segundos");
        segundos = sc.nextInt();

        System.out.println("Introduce el aumento de segundos");
        ausegundos = sc.nextInt();

        if (horas<=24 && minutos<=60 && segundos<=60) {
            ausegundos = ausegundos + segundos;
            for (int i = segundos; i < ausegundos+1; i++) {
                System.out.println("Aumento de hora: "+horas+"h "+minutos+"min "+i+"seg");
            }
        } else {
            System.out.println("Hora no correcta");
        }
    }
}

