package com.abg;

// Realizar un programa que dado un número que se solicita la usuario por consola eliminará de ese número
//todos los 0 y todos los 8 indicando adicionalmente cuántos números ha eliminado.Deberá solicitar el número mientras que
//el número introducido no sea positivo.

import java.util.Scanner;

public class ej2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num;

        System.out.println("Introduce el numero");
        num = sc.nextInt();

        while (num<0) {
            System.out.println("Introduce de nuevo el numero, debe ser positivo");
            num = sc.nextInt();
        }



    }
}
