package com.abg;

// Escribe un programa que pinte por pantalla un par de calcetines, de los que se ponen al lado del árbol de Navidad
// para que Papá Noel deje sus regalos.
//El usuario debe introducir la altura. Suponemos que el usuario introduce una altura mayor o igual a 4.
// Observa que la talla de los calcetines y la distancia
//que hay entre ellos (dos espacios) no cambia, lo único que varía es la altura.

import java.util.Scanner;

public class ej1 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int altura;

        System.out.println("Introduce la altura");
        altura = sc.nextInt();

        for (int i=0; i<altura; i++) {
            if (i<altura-1){
                System.out.println("***  ***");
            } else {
                for (int j = 0; j < altura/2-1 ; j++) {
                    System.out.println("******  ******");
                }


            }
        }
    }
}
