package com.abg;

// Ahora que se acerca la notería de Navidad queremos saber si un número va a proporcionar suerte a un usuario.
// Solicitaremos a un usuario cuáles son sus 3 números favoritos y para calcular  si un número le va a dar suerte
// dicho número tendrá más ocurrencias de esos números que de los demás.

import java.util.Scanner;

public class ej3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n1,n2,n3,loteria;

        System.out.println("Introduce el primer numero");
        n1 = sc.nextInt();
        System.out.println("Introduce el segundo numero");
        n2 = sc.nextInt();
        System.out.println("Introduce el tercer numero");
        n3 = sc.nextInt();

        System.out.println("Introduzca el numero de la loteria (5 digitos)");
        loteria = sc.nextInt();

        String cad1 = n1+"";
        String cad2 = n2+"";
        String cad3 = n3+"";
        String cad4 = loteria+"";

        if (cad4.indexOf(cad1)>0 || cad4.indexOf(cad2)>0 || cad4.indexOf(cad3)>0){
            System.out.println("Ese numero le va a dar suerte");
        } else {
            System.out.println("Ese numero no le va a dar suerte");
        }

    }
}
